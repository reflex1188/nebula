package com.example.nebulamod.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Nebula Visuals – Cosmetic + light utility features only.
 * No combat advantages, no ESP, no reach, no movement hacks.
 */
public class NebulaModClient implements ClientModInitializer {
    public static final String MOD_ID = "nebulamod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // ==================== CONFIG ====================
    public static boolean enableCustomCrosshair = true;
    public static boolean enableCustomHud = true;
    public static boolean enableKeystrokes = true;
    public static boolean enableCpsCounter = true;
    public static boolean enableFpsPing = true;
    public static boolean enableCoordinates = true;
    public static boolean enableArmorStatus = true;
    public static boolean enablePotionTimers = true;
    public static boolean enableDirection = true;

    // Nebula atmosphere colors
    public static float nebulaR = 0.42f;
    public static float nebulaG = 0.12f;
    public static float nebulaB = 0.78f;

    // Crosshair
    public static int crosshairColor = 0xFFCC66FF;
    public static int crosshairSize = 5;
    public static int crosshairThickness = 2;
    public static int crosshairGap = 3;

    // CPS tracking
    private static final List<Long> leftClicks = new ArrayList<>();
    private static final List<Long> rightClicks = new ArrayList<>();

    @Override
    public void onInitializeClient() {
        LOGGER.info("Nebula Visuals loaded – cosmetic & light utility only");
        HudRenderCallback.EVENT.register(this::onHudRender);
    }

    private void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || mc.getDebugHud().shouldShowDebugHud()) return;

        ClientPlayerEntity player = mc.player;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        // Track clicks for CPS
        trackClicks(mc);

        // 1. Custom Crosshair
        if (enableCustomCrosshair) {
            renderCrosshair(context, sw, sh);
        }

        // 2. Top-left info panel (FPS, Ping, Coords, Direction)
        int leftY = 8;
        if (enableFpsPing || enableCoordinates || enableDirection) {
            leftY = renderInfoPanel(context, mc, player, 8, leftY);
        }

        // 3. Keystrokes
        if (enableKeystrokes) {
            renderKeystrokes(context, mc, sw - 90, sh - 90);
        }

        // 4. CPS Counter
        if (enableCpsCounter) {
            renderCps(context, mc, sw - 90, sh - 115);
        }

        // 5. Armor status
        if (enableArmorStatus) {
            renderArmor(context, mc, player, 8, sh - 70);
        }

        // 6. Potion timers
        if (enablePotionTimers) {
            renderPotions(context, mc, player, sw - 130, 40);
        }

        // 7. Minimal status (health / food) – clean style
        if (enableCustomHud) {
            renderStatus(context, mc, player, sw / 2 - 50, sh - 45);
        }
    }

    // -------------------- Crosshair --------------------
    private void renderCrosshair(DrawContext ctx, int sw, int sh) {
        int cx = sw / 2;
        int cy = sh / 2;
        int size = crosshairSize;
        int thick = crosshairThickness;
        int gap = crosshairGap;

        // Horizontal lines
        ctx.fill(cx - size - gap, cy - thick / 2, cx - gap, cy + thick / 2 + (thick % 2), crosshairColor);
        ctx.fill(cx + gap, cy - thick / 2, cx + size + gap, cy + thick / 2 + (thick % 2), crosshairColor);

        // Vertical lines
        ctx.fill(cx - thick / 2, cy - size - gap, cx + thick / 2 + (thick % 2), cy - gap, crosshairColor);
        ctx.fill(cx - thick / 2, cy + gap, cx + thick / 2 + (thick % 2), cy + size + gap, crosshairColor);
    }

    // -------------------- Info Panel --------------------
    private int renderInfoPanel(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity player, int x, int y) {
        int line = 0;

        if (enableFpsPing) {
            int fps = mc.getCurrentFps();
            int ping = 0;
            if (mc.getNetworkHandler() != null && mc.player != null && mc.player.networkHandler != null) {
                var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (entry != null) ping = entry.getLatency();
            }
            ctx.drawText(mc.textRenderer, "FPS: " + fps, x, y + line * 10, 0xFF55FF55, true);
            line++;
            ctx.drawText(mc.textRenderer, "Ping: " + ping + "ms", x, y + line * 10, 0xFF55FFFF, true);
            line++;
        }

        if (enableCoordinates) {
            String coords = String.format("%.1f %.1f %.1f", player.getX(), player.getY(), player.getZ());
            ctx.drawText(mc.textRenderer, coords, x, y + line * 10, 0xFFFFFFFF, true);
            line++;
        }

        if (enableDirection) {
            Direction dir = player.getHorizontalFacing();
            String facing = dir.asString().toUpperCase() + " (" + getYawString(player.getYaw()) + ")";
            ctx.drawText(mc.textRenderer, facing, x, y + line * 10, 0xFFFFAA00, true);
            line++;
        }

        return y + line * 10 + 6;
    }

    private String getYawString(float yaw) {
        yaw = MathHelper.wrapDegrees(yaw);
        return String.format("%.0f", yaw);
    }

    // -------------------- Keystrokes --------------------
    private void renderKeystrokes(DrawContext ctx, MinecraftClient mc, int x, int y) {
        int size = 18;
        int gap = 2;

        drawKey(ctx, mc, mc.options.forwardKey, "W", x + size + gap, y, size);
        drawKey(ctx, mc, mc.options.leftKey, "A", x, y + size + gap, size);
        drawKey(ctx, mc, mc.options.backKey, "S", x + size + gap, y + size + gap, size);
        drawKey(ctx, mc, mc.options.rightKey, "D", x + (size + gap) * 2, y + size + gap, size);
        drawKey(ctx, mc, mc.options.jumpKey, "SPACE", x, y + (size + gap) * 2, size * 3 + gap * 2);
    }

    private void drawKey(DrawContext ctx, MinecraftClient mc, KeyBinding key, String label, int x, int y, int w) {
        boolean pressed = key.isPressed();
        int bg = pressed ? 0xAAFFFFFF : 0x66000000;
        int fg = pressed ? 0xFF000000 : 0xFFFFFFFF;

        ctx.fill(x, y, x + w, y + 18, bg);
        ctx.fill(x, y, x + w, y + 1, 0x33FFFFFF); // top highlight

        int tw = mc.textRenderer.getWidth(label);
        ctx.drawText(mc.textRenderer, label, x + (w - tw) / 2, y + 5, fg, false);
    }

    // -------------------- CPS --------------------
    private void trackClicks(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        // Clean old clicks (older than 1 second)
        leftClicks.removeIf(t -> now - t > 1000);
        rightClicks.removeIf(t -> now - t > 1000);

        // Note: Actual click detection needs mouse event hooks or mixins for accuracy.
        // This is a simple placeholder that can be expanded.
    }

    private void renderCps(DrawContext ctx, MinecraftClient mc, int x, int y) {
        int lCps = leftClicks.size();
        int rCps = rightClicks.size();
        ctx.drawText(mc.textRenderer, "CPS: " + lCps + " | " + rCps, x, y, 0xFFFF55FF, true);
    }

    // -------------------- Armor --------------------
    private void renderArmor(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity player, int x, int y) {
        int slot = 0;
        for (ItemStack stack : player.getArmorItems()) {
            if (!stack.isEmpty()) {
                int durability = stack.getMaxDamage() - stack.getDamage();
                int max = stack.getMaxDamage();
                float pct = max > 0 ? (float) durability / max : 1f;

                int color = pct > 0.6f ? 0xFF55FF55 : pct > 0.3f ? 0xFFFFFF55 : 0xFFFF5555;
                ctx.drawText(mc.textRenderer, "A" + (4 - slot) + ": " + durability, x, y + slot * 10, color, true);
            }
            slot++;
        }
    }

    // -------------------- Potions --------------------
    private void renderPotions(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity player, int x, int y) {
        int line = 0;
        for (StatusEffectInstance effect : player.getStatusEffects()) {
            if (effect == null) continue;
            String name = effect.getEffectType().value().getName().getString();
            int secs = effect.getDuration() / 20;
            String text = name + " " + (secs / 60) + ":" + String.format("%02d", secs % 60);
            ctx.drawText(mc.textRenderer, text, x, y + line * 10, 0xFFDD88FF, true);
            line++;
            if (line > 8) break; // don't spam the screen
        }
    }

    // -------------------- Clean Status --------------------
    private void renderStatus(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity player, int x, int y) {
        float health = player.getHealth();
        float maxHp = player.getMaxHealth();
        int food = player.getHungerManager().getFoodLevel();

        // Background
        ctx.fill(x - 4, y - 3, x + 108, y + 24, 0x66000000);

        ctx.drawText(mc.textRenderer, String.format("❤ %.1f/%.1f", health, maxHp), x, y, 0xFFFF5555, true);
        ctx.drawText(mc.textRenderer, "🍗 " + food + "/20", x, y + 11, 0xFFFFAA00, true);
    }
}
