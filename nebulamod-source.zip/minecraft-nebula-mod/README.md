# Nebula Visuals Mod

Client-side Fabric mod with **cosmetic + light utility features only**.

No combat advantages. No ESP. No reach. No movement hacks.

## Features

### Cosmetic
- Custom crosshair (color, size, thickness, gap)
- Clean custom status display (health + hunger)
- Nebula atmosphere color settings (ready for expansion)

### Light Utility (display only)
- FPS + Ping
- Coordinates
- Direction / facing
- Keystrokes
- CPS counter (left | right)
- Armor durability
- Potion effect timers

## Requirements
- Minecraft 26.3
- Fabric Loader
- Fabric API
- Works with Dawn Client

## Configuration
All features can be toggled at the top of `NebulaModClient.java`.

## Building
This is source code. To use it you need to compile it with a proper Fabric development environment for Minecraft 26.3.

## Notes
- CPS tracking is basic and can be improved with proper mouse input hooks.
- Full nebula sky still works best with a shader (Iris).
- Everything is client-side and should not trigger anti-cheat on normal servers when used as pure display features.
